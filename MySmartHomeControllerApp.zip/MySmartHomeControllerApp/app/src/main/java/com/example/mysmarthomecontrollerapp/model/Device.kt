package com.example.mysmarthomecontrollerapp.model

data class Device(
    val id: String,
    val name: String,
    val status: String,
    val type: String
)
